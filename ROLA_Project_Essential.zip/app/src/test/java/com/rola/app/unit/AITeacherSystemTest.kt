package com.rola.app.unit

import com.rola.app.ai_teacher.assessment.AssessmentGenerator
import com.rola.app.ai_teacher.lesson.LessonGenerator
import com.rola.app.ai_teacher.personalization.AdaptiveTeachingEngine
import com.rola.app.ai_teacher.teaching.CurriculumQualityValidator
import com.rola.app.domain.model.CurriculumModule
import com.rola.app.domain.model.CurriculumRequest
import com.rola.app.domain.model.GeneratedCurriculum
import com.rola.app.domain.model.LearningProfile
import com.rola.app.domain.model.LearningSpeed
import com.rola.app.domain.model.SkillLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AITeacherSystemTest {
    private val lessonGenerator = LessonGenerator()
    private val assessmentGenerator = AssessmentGenerator()
    private val adaptiveTeachingEngine = AdaptiveTeachingEngine()
    private val qualityValidator = CurriculumQualityValidator()

    @Test
    fun generatedLessonIncludesObjectivesArActivitiesAndPractice() {
        val lesson = lessonGenerator.generateLesson(
            topic = "Electricity",
            objective = "Explain current and voltage.",
            level = SkillLevel.Beginner,
            relatedConcepts = listOf("Copper", "Circuit"),
        )

        assertEquals(SkillLevel.Beginner, lesson.difficulty)
        assertTrue(lesson.objectives.any { it.contains("Electricity") })
        assertTrue(lesson.arActivities.isNotEmpty())
        assertTrue(lesson.practiceQuestions.isNotEmpty())
    }

    @Test
    fun advancedAssessmentAddsHigherOrderQuestion() {
        val assessment = assessmentGenerator.generateAssessment("Metals", SkillLevel.Advanced)

        assertEquals(SkillLevel.Advanced, assessment.difficulty)
        assertTrue(assessment.mcqQuestions.any { it.contains("exception", ignoreCase = true) })
        assertTrue(assessment.arAssignments.isNotEmpty())
    }

    @Test
    fun qualityValidationRequiresObjectivesAssessmentAndArActivity() {
        val lesson = lessonGenerator.generateLesson("Circuits", "Build a simple circuit.", SkillLevel.Intermediate, listOf("Battery"))
        val curriculum = GeneratedCurriculum(
            curriculumId = "curriculum-1",
            teacherId = "teacher-1",
            institutionId = "institution-1",
            request = CurriculumRequest("Physics", "Electricity", "Grade 7", "Build a simple circuit.", 1, SkillLevel.Intermediate),
            title = "Electricity",
            overview = "A short electricity unit.",
            modules = listOf(CurriculumModule("module-1", "Current", "Explain current.", listOf(lesson), 2)),
            assessments = listOf(assessmentGenerator.generateAssessment("Circuits", SkillLevel.Intermediate)),
            quality = qualityValidator.placeholderReport(),
        )

        val report = qualityValidator.validate(curriculum, "Knowledge graph context is available.")

        assertTrue(report.publishReady)
        assertTrue(report.scientificAccuracy >= 0.75f)
    }

    @Test
    fun adaptiveTeachingUsesStudentHistorySignals() {
        val plan = adaptiveTeachingEngine.adapt(
            teacherId = "teacher-1",
            profile = LearningProfile(
                userId = "student-1",
                totalObjectsLearned = 12,
                averageQuizScore = 55,
                favoriteCategories = listOf("Physics"),
                weakAreas = listOf("Circuits"),
                learningLevel = SkillLevel.Beginner,
                learningStreak = 2,
                totalLearningTimeMillis = 3_600_000,
                frequentlySearchedTopics = listOf("Battery"),
                difficultConcepts = listOf("Resistance"),
                preferredLanguage = "en",
                learningSpeed = LearningSpeed.SlowAndSteady,
            ),
        )

        assertEquals(LearningSpeed.SlowAndSteady, plan.learningSpeed)
        assertFalse(plan.recommendedInterventions.isEmpty())
        assertTrue(plan.exampleStrategy.contains("Physics"))
    }
}
