package com.rola.app.ai_teacher.teaching

import com.rola.app.data.knowledgegraph.KnowledgeGraphRepository
import com.rola.app.domain.model.ClassroomAssistantResponse
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ClassroomAssistant @Inject constructor(
    private val knowledgeGraphRepository: KnowledgeGraphRepository,
) {
    suspend fun answerDuringClass(
        question: String,
        topic: String,
    ): ClassroomAssistantResponse {
        val context = knowledgeGraphRepository.groundedTutorContext("$topic $question")
        return ClassroomAssistantResponse(
            question = question,
            answer = if (context.isBlank()) {
                "Let's connect $topic to a visible object, then test the idea with a simple example."
            } else {
                "Using the knowledge map: ${context.lines().take(3).joinToString(" ")}"
            },
            examples = listOf("Show a real object related to $topic.", "Ask students to compare two observations."),
            demonstrations = listOf("AR scan demonstration", "Think-pair-share explanation", "One-question understanding check"),
            understandingSignal = "Ask students to explain $topic in one sentence and identify one example.",
        )
    }
}
