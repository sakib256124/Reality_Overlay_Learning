package com.rola.app.ai_teacher.teaching

import com.rola.app.ai_teacher.assessment.AssessmentGenerator
import com.rola.app.ai_teacher.curriculum.CurriculumGenerator
import com.rola.app.ai_teacher.lesson.LessonGenerator
import com.rola.app.ai_teacher.personalization.AdaptiveTeachingEngine
import com.rola.app.data.adaptive.UserProfileRepository
import com.rola.app.domain.model.AITeacherAssessment
import com.rola.app.domain.model.AdaptiveTeachingPlan
import com.rola.app.domain.model.ClassroomAssistantResponse
import com.rola.app.domain.model.CurriculumRequest
import com.rola.app.domain.model.GeneratedCurriculum
import com.rola.app.domain.model.GeneratedLesson
import com.rola.app.domain.model.SkillLevel
import com.rola.app.domain.model.TeacherApprovalStatus
import com.rola.app.domain.model.TeacherReviewRecord
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AITeacherEngine @Inject constructor(
    private val curriculumGenerator: CurriculumGenerator,
    private val lessonGenerator: LessonGenerator,
    private val assessmentGenerator: AssessmentGenerator,
    private val adaptiveTeachingEngine: AdaptiveTeachingEngine,
    private val classroomAssistant: ClassroomAssistant,
    private val userProfileRepository: UserProfileRepository,
    private val aiTeacherRepository: AITeacherRepository,
) {
    suspend fun generateCurriculum(
        teacherId: String,
        institutionId: String,
        request: CurriculumRequest,
    ): GeneratedCurriculum {
        val curriculum = curriculumGenerator.generateCurriculum(
            teacherId = teacherId,
            institutionId = institutionId,
            request = request,
        )
        aiTeacherRepository.saveCurriculum(curriculum)
        return curriculum
    }

    fun generateLesson(
        topic: String,
        objective: String,
        level: SkillLevel,
        relatedConcepts: List<String>,
    ): GeneratedLesson = lessonGenerator.generateLesson(topic, objective, level, relatedConcepts)

    fun generateAssessment(
        topic: String,
        level: SkillLevel,
    ): AITeacherAssessment = assessmentGenerator.generateAssessment(topic, level)

    suspend fun createAdaptiveTeachingPlan(teacherId: String): AdaptiveTeachingPlan {
        val profile = runCatching { userProfileRepository.refreshLearningProfile() }.getOrNull()
        return adaptiveTeachingEngine.adapt(teacherId, profile).also {
            aiTeacherRepository.saveTeachingPlan(it)
        }
    }

    suspend fun answerDuringClass(
        question: String,
        topic: String,
    ): ClassroomAssistantResponse = classroomAssistant.answerDuringClass(question, topic)

    suspend fun submitForTeacherReview(curriculum: GeneratedCurriculum): GeneratedCurriculum {
        val pending = curriculum.copy(
            approvalStatus = TeacherApprovalStatus.PendingReview,
            updatedAt = System.currentTimeMillis(),
        )
        aiTeacherRepository.saveCurriculum(pending)
        return pending
    }

    suspend fun approveGeneratedContent(
        curriculumId: String,
        teacherId: String,
        comments: String,
        distributeToStudents: Boolean = false,
    ): TeacherReviewRecord {
        val status = if (distributeToStudents) TeacherApprovalStatus.Distributed else TeacherApprovalStatus.Approved
        val review = TeacherReviewRecord(
            reviewId = "teacher-review-${UUID.randomUUID()}",
            contentId = curriculumId,
            teacherId = teacherId,
            status = status,
            comments = comments,
        )
        aiTeacherRepository.saveReview(review)
        return review
    }

    suspend fun rejectGeneratedContent(
        curriculumId: String,
        teacherId: String,
        comments: String,
    ): TeacherReviewRecord {
        val review = TeacherReviewRecord(
            reviewId = "teacher-review-${UUID.randomUUID()}",
            contentId = curriculumId,
            teacherId = teacherId,
            status = TeacherApprovalStatus.Rejected,
            comments = comments,
        )
        aiTeacherRepository.saveReview(review)
        return review
    }

    fun recommendActivities(lesson: GeneratedLesson): List<String> =
        lesson.arActivities.map { "${it.title}: ${it.description}" } +
            lesson.experiments.map { "Experiment: $it" } +
            lesson.practiceQuestions.take(2).map { "Check: $it" }
}
