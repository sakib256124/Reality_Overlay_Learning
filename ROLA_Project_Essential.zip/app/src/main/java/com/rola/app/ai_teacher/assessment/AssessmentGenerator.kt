package com.rola.app.ai_teacher.assessment

import com.rola.app.domain.model.AITeacherAssessment
import com.rola.app.domain.model.SkillLevel
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AssessmentGenerator @Inject constructor() {
    fun generateAssessment(
        topic: String,
        level: SkillLevel,
    ): AITeacherAssessment = AITeacherAssessment(
        assessmentId = "assessment-${UUID.randomUUID()}",
        title = "$topic ${level.name} Assessment",
        difficulty = level,
        mcqQuestions = listOf(
            "Which statement best defines $topic?",
            "Which example shows $topic in the real world?",
            "What evidence would support an explanation of $topic?",
        ) + if (level == SkillLevel.Advanced) listOf("Which exception or limitation should be considered?") else emptyList(),
        practicalTasks = listOf("Explain $topic using one observed object.", "Compare $topic across two examples."),
        arAssignments = listOf("Scan a relevant object and identify evidence of $topic."),
        researchActivities = listOf("Find one trusted source that explains $topic and summarize it."),
    )
}
