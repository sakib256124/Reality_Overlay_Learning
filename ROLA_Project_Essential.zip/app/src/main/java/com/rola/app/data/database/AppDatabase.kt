package com.rola.app.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.rola.app.data.database.converters.QuizConverters
import com.rola.app.data.database.converters.StringListConverter
import com.rola.app.data.database.entities.ChatMessageEntity
import com.rola.app.data.database.entities.AssignmentEntity
import com.rola.app.data.database.entities.AssignmentSubmissionEntity
import com.rola.app.data.database.entities.ClassGroupEntity
import com.rola.app.data.database.entities.ClassroomSessionEntity
import com.rola.app.data.database.entities.AICurriculumEntity
import com.rola.app.data.database.entities.AITeacherAssessmentEntity
import com.rola.app.data.database.entities.ARLearningActivityEntity
import com.rola.app.data.database.entities.AdaptiveTeachingPlanEntity
import com.rola.app.data.database.entities.KnowledgeNodeEntity
import com.rola.app.data.database.entities.KnowledgeRelationEntity
import com.rola.app.data.database.entities.LanguageEntity
import com.rola.app.data.database.entities.LearningProfileEntity
import com.rola.app.data.database.entities.LearningPathEntity
import com.rola.app.data.database.entities.ObjectEntity
import com.rola.app.data.database.entities.QuizEntity
import com.rola.app.data.database.entities.QuizResultEntity
import com.rola.app.data.database.entities.RecommendationEntity
import com.rola.app.data.database.entities.ContentVersionEntity
import com.rola.app.data.database.entities.CourseEntity
import com.rola.app.data.database.entities.CurriculumModuleEntity
import com.rola.app.data.database.entities.DepartmentEntity
import com.rola.app.data.database.entities.EnterpriseAuditLogEntity
import com.rola.app.data.database.entities.EnterpriseRoleEntity
import com.rola.app.data.database.entities.GeneratedLessonEntity
import com.rola.app.data.database.entities.InstitutionAnalyticsEntity
import com.rola.app.data.database.entities.InstitutionEntity
import com.rola.app.data.database.entities.InstitutionMemberEntity
import com.rola.app.data.database.entities.KnowledgeUpdateEntity
import com.rola.app.data.database.entities.LMSConnectionEntity
import com.rola.app.data.database.entities.LearningMaterialEntity
import com.rola.app.data.database.entities.LessonAnalyticsEntity
import com.rola.app.data.database.entities.ResearchTaskEntity
import com.rola.app.data.database.entities.ScanHistoryEntity
import com.rola.app.data.database.entities.ScientificSourceEntity
import com.rola.app.data.database.entities.StudentReportEntity
import com.rola.app.data.database.entities.TeacherReviewEntity
import com.rola.app.data.database.entities.TranslationCacheEntity
import com.rola.app.data.database.entities.UserEntity

@Database(
    entities = [
        UserEntity::class,
        ObjectEntity::class,
        ScanHistoryEntity::class,
        QuizEntity::class,
        QuizResultEntity::class,
        ChatMessageEntity::class,
        LanguageEntity::class,
        TranslationCacheEntity::class,
        LearningProfileEntity::class,
        RecommendationEntity::class,
        KnowledgeNodeEntity::class,
        KnowledgeRelationEntity::class,
        LearningPathEntity::class,
        ResearchTaskEntity::class,
        ScientificSourceEntity::class,
        KnowledgeUpdateEntity::class,
        LearningMaterialEntity::class,
        ContentVersionEntity::class,
        EnterpriseRoleEntity::class,
        InstitutionEntity::class,
        DepartmentEntity::class,
        CourseEntity::class,
        ClassGroupEntity::class,
        InstitutionMemberEntity::class,
        AssignmentEntity::class,
        AssignmentSubmissionEntity::class,
        ClassroomSessionEntity::class,
        InstitutionAnalyticsEntity::class,
        StudentReportEntity::class,
        LMSConnectionEntity::class,
        EnterpriseAuditLogEntity::class,
        AICurriculumEntity::class,
        CurriculumModuleEntity::class,
        GeneratedLessonEntity::class,
        ARLearningActivityEntity::class,
        AITeacherAssessmentEntity::class,
        AdaptiveTeachingPlanEntity::class,
        TeacherReviewEntity::class,
        LessonAnalyticsEntity::class,
    ],
    version = 11,
    exportSchema = true,
)
@TypeConverters(StringListConverter::class, QuizConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun objectDao(): ObjectDao
    abstract fun scanHistoryDao(): ScanHistoryDao
    abstract fun quizDao(): QuizDao
    abstract fun quizResultDao(): QuizResultDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun translationDao(): TranslationDao
    abstract fun adaptiveLearningDao(): AdaptiveLearningDao
    abstract fun knowledgeGraphDao(): KnowledgeGraphDao
    abstract fun researchDao(): ResearchDao
    abstract fun enterpriseDao(): EnterpriseDao
    abstract fun aiTeacherDao(): AITeacherDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE learning_objects ADD COLUMN facts TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE learning_objects ADD COLUMN isSynced INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE learning_objects ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS users (
                        userId TEXT NOT NULL PRIMARY KEY,
                        name TEXT NOT NULL,
                        email TEXT NOT NULL,
                        profileImage TEXT NOT NULL,
                        isSynced INTEGER NOT NULL DEFAULT 0,
                        updatedAt INTEGER NOT NULL DEFAULT 0
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS scan_history (
                        scanId TEXT NOT NULL PRIMARY KEY,
                        userId TEXT NOT NULL,
                        objectId TEXT NOT NULL,
                        timestamp INTEGER NOT NULL,
                        confidenceScore REAL NOT NULL,
                        learningStatus TEXT NOT NULL,
                        isSynced INTEGER NOT NULL DEFAULT 0,
                        updatedAt INTEGER NOT NULL DEFAULT 0,
                        FOREIGN KEY(userId) REFERENCES users(userId) ON UPDATE NO ACTION ON DELETE CASCADE,
                        FOREIGN KEY(objectId) REFERENCES learning_objects(objectId) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_scan_history_userId ON scan_history(userId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_scan_history_objectId ON scan_history(objectId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_scan_history_timestamp ON scan_history(timestamp)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_scan_history_isSynced ON scan_history(isSynced)")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS quizzes (
                        quizId TEXT NOT NULL PRIMARY KEY,
                        objectId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        difficulty TEXT NOT NULL,
                        questionsJson TEXT NOT NULL,
                        createdDate INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_quizzes_objectId ON quizzes(objectId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS quiz_results (
                        resultId TEXT NOT NULL PRIMARY KEY,
                        userId TEXT NOT NULL,
                        quizId TEXT NOT NULL,
                        score INTEGER NOT NULL,
                        totalQuestions INTEGER NOT NULL,
                        percentage INTEGER NOT NULL,
                        completionTime INTEGER NOT NULL,
                        timestamp INTEGER NOT NULL,
                        isSynced INTEGER NOT NULL DEFAULT 0,
                        updatedAt INTEGER NOT NULL DEFAULT 0,
                        FOREIGN KEY(userId) REFERENCES users(userId) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_quiz_results_userId ON quiz_results(userId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_quiz_results_quizId ON quiz_results(quizId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_quiz_results_timestamp ON quiz_results(timestamp)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_quiz_results_isSynced ON quiz_results(isSynced)")
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS chat_messages (
                        messageId TEXT NOT NULL PRIMARY KEY,
                        userId TEXT NOT NULL,
                        objectId TEXT,
                        role TEXT NOT NULL,
                        content TEXT NOT NULL,
                        timestamp INTEGER NOT NULL,
                        isGrounded INTEGER NOT NULL DEFAULT 1
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_chat_messages_userId ON chat_messages(userId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_chat_messages_objectId ON chat_messages(objectId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_chat_messages_timestamp ON chat_messages(timestamp)")
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS languages (
                        languageCode TEXT NOT NULL PRIMARY KEY,
                        languageName TEXT NOT NULL,
                        nativeName TEXT NOT NULL,
                        supportedVoice INTEGER NOT NULL,
                        isDownloaded INTEGER NOT NULL DEFAULT 0,
                        lastUsedAt INTEGER NOT NULL DEFAULT 0
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS translation_cache (
                        cacheId TEXT NOT NULL PRIMARY KEY,
                        sourceText TEXT NOT NULL,
                        sourceLanguage TEXT NOT NULL,
                        targetLanguage TEXT NOT NULL,
                        translatedText TEXT NOT NULL,
                        timestamp INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_translation_cache_sourceLanguage_targetLanguage ON translation_cache(sourceLanguage, targetLanguage)",
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_translation_cache_timestamp ON translation_cache(timestamp)")
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS learning_profiles (
                        userId TEXT NOT NULL PRIMARY KEY,
                        totalObjectsLearned INTEGER NOT NULL,
                        averageQuizScore INTEGER NOT NULL,
                        favoriteCategories TEXT NOT NULL,
                        weakAreas TEXT NOT NULL,
                        learningLevel TEXT NOT NULL,
                        learningStreak INTEGER NOT NULL,
                        totalLearningTimeMillis INTEGER NOT NULL,
                        frequentlySearchedTopics TEXT NOT NULL,
                        difficultConcepts TEXT NOT NULL,
                        preferredLanguage TEXT NOT NULL,
                        learningSpeed TEXT NOT NULL,
                        personalizationEnabled INTEGER NOT NULL DEFAULT 1,
                        isSynced INTEGER NOT NULL DEFAULT 0,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS recommendations (
                        recommendationId TEXT NOT NULL PRIMARY KEY,
                        userId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        description TEXT NOT NULL,
                        topic TEXT NOT NULL,
                        type TEXT NOT NULL,
                        priority TEXT NOT NULL,
                        targetSkillLevel TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        completed INTEGER NOT NULL DEFAULT 0,
                        isSynced INTEGER NOT NULL DEFAULT 0,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recommendations_userId ON recommendations(userId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recommendations_priority ON recommendations(priority)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recommendations_completed ON recommendations(completed)")
            }
        }

        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS knowledge_nodes (
                        nodeId TEXT NOT NULL PRIMARY KEY,
                        name TEXT NOT NULL,
                        type TEXT NOT NULL,
                        description TEXT NOT NULL,
                        category TEXT NOT NULL,
                        aliases TEXT NOT NULL DEFAULT '',
                        tags TEXT NOT NULL DEFAULT '',
                        verified INTEGER NOT NULL DEFAULT 1,
                        source TEXT NOT NULL DEFAULT 'ROLA Knowledge Graph',
                        isSynced INTEGER NOT NULL DEFAULT 1,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_nodes_name ON knowledge_nodes(name)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_nodes_type ON knowledge_nodes(type)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_nodes_category ON knowledge_nodes(category)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_nodes_verified ON knowledge_nodes(verified)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS knowledge_relations (
                        relationId TEXT NOT NULL PRIMARY KEY,
                        sourceNodeId TEXT NOT NULL,
                        targetNodeId TEXT NOT NULL,
                        type TEXT NOT NULL,
                        description TEXT NOT NULL,
                        confidence REAL NOT NULL DEFAULT 1.0,
                        verified INTEGER NOT NULL DEFAULT 1,
                        createdBy TEXT NOT NULL DEFAULT 'system',
                        isSynced INTEGER NOT NULL DEFAULT 1,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_relations_sourceNodeId ON knowledge_relations(sourceNodeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_relations_targetNodeId ON knowledge_relations(targetNodeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_relations_type ON knowledge_relations(type)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_relations_verified ON knowledge_relations(verified)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS learning_paths (
                        pathId TEXT NOT NULL PRIMARY KEY,
                        title TEXT NOT NULL,
                        description TEXT NOT NULL,
                        targetLevel TEXT NOT NULL,
                        topic TEXT NOT NULL,
                        nodeIds TEXT NOT NULL DEFAULT '',
                        estimatedMinutes INTEGER NOT NULL,
                        generatedBy TEXT NOT NULL DEFAULT 'knowledge_graph',
                        isSynced INTEGER NOT NULL DEFAULT 1,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_learning_paths_topic ON learning_paths(topic)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_learning_paths_targetLevel ON learning_paths(targetLevel)")
            }
        }

        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS research_tasks (
                        taskId TEXT NOT NULL PRIMARY KEY,
                        topic TEXT NOT NULL,
                        reason TEXT NOT NULL,
                        priority TEXT NOT NULL,
                        status TEXT NOT NULL,
                        suggestedSources TEXT NOT NULL DEFAULT '',
                        assignedTo TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_research_tasks_topic ON research_tasks(topic)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_research_tasks_status ON research_tasks(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_research_tasks_priority ON research_tasks(priority)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS scientific_sources (
                        sourceId TEXT NOT NULL PRIMARY KEY,
                        title TEXT NOT NULL,
                        url TEXT NOT NULL,
                        sourceType TEXT NOT NULL,
                        reliability TEXT NOT NULL,
                        publisher TEXT NOT NULL,
                        authors TEXT NOT NULL DEFAULT '',
                        publicationYear INTEGER,
                        topics TEXT NOT NULL DEFAULT '',
                        trusted INTEGER NOT NULL DEFAULT 0,
                        addedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_scientific_sources_sourceType ON scientific_sources(sourceType)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_scientific_sources_reliability ON scientific_sources(reliability)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_scientific_sources_trusted ON scientific_sources(trusted)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS knowledge_updates (
                        updateId TEXT NOT NULL PRIMARY KEY,
                        taskId TEXT NOT NULL,
                        topic TEXT NOT NULL,
                        summary TEXT NOT NULL,
                        definitions TEXT NOT NULL DEFAULT '',
                        properties TEXT NOT NULL DEFAULT '',
                        applications TEXT NOT NULL DEFAULT '',
                        examples TEXT NOT NULL DEFAULT '',
                        relationSuggestions TEXT NOT NULL DEFAULT '',
                        difficultyLevel TEXT NOT NULL,
                        sourceIds TEXT NOT NULL DEFAULT '',
                        reliabilityScore REAL NOT NULL,
                        duplicateRisk REAL NOT NULL,
                        consistencyScore REAL NOT NULL,
                        contradictionRisk REAL NOT NULL,
                        moderationStatus TEXT NOT NULL,
                        verificationNotes TEXT NOT NULL DEFAULT '',
                        status TEXT NOT NULL,
                        version INTEGER NOT NULL,
                        createdAt INTEGER NOT NULL,
                        approvedAt INTEGER,
                        approvedBy TEXT
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_updates_taskId ON knowledge_updates(taskId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_updates_topic ON knowledge_updates(topic)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_updates_status ON knowledge_updates(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_knowledge_updates_createdAt ON knowledge_updates(createdAt)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS learning_materials (
                        materialId TEXT NOT NULL PRIMARY KEY,
                        topic TEXT NOT NULL,
                        materialType TEXT NOT NULL,
                        title TEXT NOT NULL,
                        beginnerExplanation TEXT NOT NULL,
                        advancedExplanation TEXT NOT NULL,
                        summary TEXT NOT NULL,
                        quizQuestions TEXT NOT NULL DEFAULT '',
                        flashcards TEXT NOT NULL DEFAULT '',
                        sourceUpdateId TEXT NOT NULL,
                        version INTEGER NOT NULL,
                        status TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_learning_materials_topic ON learning_materials(topic)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_learning_materials_materialType ON learning_materials(materialType)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_learning_materials_status ON learning_materials(status)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS content_versions (
                        versionId TEXT NOT NULL PRIMARY KEY,
                        contentId TEXT NOT NULL,
                        contentType TEXT NOT NULL,
                        version INTEGER NOT NULL,
                        sourceIds TEXT NOT NULL DEFAULT '',
                        changeSummary TEXT NOT NULL,
                        modifiedBy TEXT NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_content_versions_contentId ON content_versions(contentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_content_versions_contentType ON content_versions(contentType)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_content_versions_createdAt ON content_versions(createdAt)")
            }
        }

        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS enterprise_roles (
                        roleId TEXT NOT NULL PRIMARY KEY,
                        userId TEXT NOT NULL,
                        institutionId TEXT NOT NULL,
                        role TEXT NOT NULL,
                        permissions TEXT NOT NULL DEFAULT '',
                        active INTEGER NOT NULL DEFAULT 1,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_enterprise_roles_institutionId ON enterprise_roles(institutionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_enterprise_roles_role ON enterprise_roles(role)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS institutions (
                        institutionId TEXT NOT NULL PRIMARY KEY,
                        name TEXT NOT NULL,
                        type TEXT NOT NULL,
                        domain TEXT NOT NULL,
                        region TEXT NOT NULL,
                        adminUserIds TEXT NOT NULL DEFAULT '',
                        active INTEGER NOT NULL DEFAULT 1,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_institutions_name ON institutions(name)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_institutions_active ON institutions(active)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS departments (
                        departmentId TEXT NOT NULL PRIMARY KEY,
                        institutionId TEXT NOT NULL,
                        name TEXT NOT NULL,
                        description TEXT NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_departments_institutionId ON departments(institutionId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS courses (
                        courseId TEXT NOT NULL PRIMARY KEY,
                        institutionId TEXT NOT NULL,
                        departmentId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        description TEXT NOT NULL,
                        subject TEXT NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_courses_institutionId ON courses(institutionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_courses_departmentId ON courses(departmentId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS classes (
                        classId TEXT NOT NULL PRIMARY KEY,
                        institutionId TEXT NOT NULL,
                        courseId TEXT NOT NULL,
                        teacherId TEXT NOT NULL,
                        name TEXT NOT NULL,
                        studentIds TEXT NOT NULL DEFAULT '',
                        schedule TEXT NOT NULL DEFAULT '',
                        active INTEGER NOT NULL DEFAULT 1
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_classes_institutionId ON classes(institutionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_classes_courseId ON classes(courseId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_classes_teacherId ON classes(teacherId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS members (
                        memberId TEXT NOT NULL PRIMARY KEY,
                        institutionId TEXT NOT NULL,
                        userId TEXT NOT NULL,
                        role TEXT NOT NULL,
                        displayName TEXT NOT NULL,
                        email TEXT NOT NULL DEFAULT '',
                        parentUserIds TEXT NOT NULL DEFAULT '',
                        active INTEGER NOT NULL DEFAULT 1
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_members_institutionId ON members(institutionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_members_userId ON members(userId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_members_role ON members(role)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS assignments (
                        assignmentId TEXT NOT NULL PRIMARY KEY,
                        teacherId TEXT NOT NULL,
                        classId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        description TEXT NOT NULL,
                        assignmentType TEXT NOT NULL,
                        deadline INTEGER NOT NULL,
                        evaluationCriteria TEXT NOT NULL DEFAULT '',
                        targetObjectIds TEXT NOT NULL DEFAULT '',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_assignments_teacherId ON assignments(teacherId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_assignments_classId ON assignments(classId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_assignments_deadline ON assignments(deadline)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS submissions (
                        submissionId TEXT NOT NULL PRIMARY KEY,
                        assignmentId TEXT NOT NULL,
                        studentId TEXT NOT NULL,
                        status TEXT NOT NULL,
                        score INTEGER,
                        feedback TEXT NOT NULL DEFAULT '',
                        submittedAt INTEGER
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_submissions_assignmentId ON submissions(assignmentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_submissions_studentId ON submissions(studentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_submissions_status ON submissions(status)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS classroom_sessions (
                        sessionId TEXT NOT NULL PRIMARY KEY,
                        classId TEXT NOT NULL,
                        teacherId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        sharedObjectIds TEXT NOT NULL DEFAULT '',
                        participantIds TEXT NOT NULL DEFAULT '',
                        status TEXT NOT NULL,
                        startedAt INTEGER,
                        endedAt INTEGER
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_classroom_sessions_classId ON classroom_sessions(classId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_classroom_sessions_teacherId ON classroom_sessions(teacherId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_classroom_sessions_status ON classroom_sessions(status)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS teacher_analytics (
                        reportId TEXT NOT NULL PRIMARY KEY,
                        institutionId TEXT NOT NULL,
                        classId TEXT,
                        completionRate INTEGER NOT NULL,
                        averageQuizScore INTEGER NOT NULL,
                        engagementScore INTEGER NOT NULL,
                        weakAreas TEXT NOT NULL DEFAULT '',
                        learningTrends TEXT NOT NULL DEFAULT '',
                        generatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_teacher_analytics_institutionId ON teacher_analytics(institutionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_teacher_analytics_classId ON teacher_analytics(classId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_teacher_analytics_generatedAt ON teacher_analytics(generatedAt)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS student_reports (
                        reportId TEXT NOT NULL PRIMARY KEY,
                        studentId TEXT NOT NULL,
                        classId TEXT NOT NULL,
                        progressPercent INTEGER NOT NULL,
                        completedLessons INTEGER NOT NULL,
                        averageQuizScore INTEGER NOT NULL,
                        achievements TEXT NOT NULL DEFAULT '',
                        recommendations TEXT NOT NULL DEFAULT '',
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_student_reports_studentId ON student_reports(studentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_student_reports_classId ON student_reports(classId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS lms_connections (
                        connectionId TEXT NOT NULL PRIMARY KEY,
                        institutionId TEXT NOT NULL,
                        provider TEXT NOT NULL,
                        status TEXT NOT NULL,
                        syncEnabled INTEGER NOT NULL DEFAULT 0,
                        lastSyncAt INTEGER
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_lms_connections_institutionId ON lms_connections(institutionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_lms_connections_provider ON lms_connections(provider)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_lms_connections_status ON lms_connections(status)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS enterprise_audit_logs (
                        auditId TEXT NOT NULL PRIMARY KEY,
                        institutionId TEXT NOT NULL,
                        actorUserId TEXT NOT NULL,
                        action TEXT NOT NULL,
                        targetType TEXT NOT NULL,
                        targetId TEXT NOT NULL,
                        timestamp INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_enterprise_audit_logs_institutionId ON enterprise_audit_logs(institutionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_enterprise_audit_logs_actorUserId ON enterprise_audit_logs(actorUserId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_enterprise_audit_logs_timestamp ON enterprise_audit_logs(timestamp)")
            }
        }

        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS ai_curriculums (
                        curriculumId TEXT NOT NULL PRIMARY KEY,
                        teacherId TEXT NOT NULL,
                        institutionId TEXT NOT NULL,
                        subject TEXT NOT NULL,
                        topic TEXT NOT NULL,
                        gradeLevel TEXT NOT NULL,
                        learningObjective TEXT NOT NULL,
                        durationWeeks INTEGER NOT NULL,
                        studentLevel TEXT NOT NULL,
                        languageCode TEXT NOT NULL,
                        title TEXT NOT NULL,
                        overview TEXT NOT NULL,
                        moduleIds TEXT NOT NULL DEFAULT '',
                        assessmentIds TEXT NOT NULL DEFAULT '',
                        scientificAccuracy REAL NOT NULL,
                        levelAlignment REAL NOT NULL,
                        objectiveCoverage REAL NOT NULL,
                        contentConsistency REAL NOT NULL,
                        qualityNotes TEXT NOT NULL DEFAULT '',
                        approvalStatus TEXT NOT NULL,
                        ownerUserId TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ai_curriculums_teacherId ON ai_curriculums(teacherId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ai_curriculums_institutionId ON ai_curriculums(institutionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ai_curriculums_approvalStatus ON ai_curriculums(approvalStatus)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS curriculum_modules (
                        moduleId TEXT NOT NULL PRIMARY KEY,
                        curriculumId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        objective TEXT NOT NULL,
                        lessonIds TEXT NOT NULL DEFAULT '',
                        estimatedHours INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_curriculum_modules_curriculumId ON curriculum_modules(curriculumId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS lessons (
                        lessonId TEXT NOT NULL PRIMARY KEY,
                        curriculumId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        objectives TEXT NOT NULL DEFAULT '',
                        explanation TEXT NOT NULL,
                        examples TEXT NOT NULL DEFAULT '',
                        experiments TEXT NOT NULL DEFAULT '',
                        arActivityIds TEXT NOT NULL DEFAULT '',
                        practiceQuestions TEXT NOT NULL DEFAULT '',
                        difficulty TEXT NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_lessons_curriculumId ON lessons(curriculumId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_lessons_difficulty ON lessons(difficulty)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS activities (
                        activityId TEXT NOT NULL PRIMARY KEY,
                        lessonId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        description TEXT NOT NULL,
                        suggestedObjectIds TEXT NOT NULL DEFAULT '',
                        activityType TEXT NOT NULL,
                        estimatedMinutes INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_activities_lessonId ON activities(lessonId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_activities_activityType ON activities(activityType)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS assessments (
                        assessmentId TEXT NOT NULL PRIMARY KEY,
                        curriculumId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        difficulty TEXT NOT NULL,
                        mcqQuestions TEXT NOT NULL DEFAULT '',
                        practicalTasks TEXT NOT NULL DEFAULT '',
                        arAssignments TEXT NOT NULL DEFAULT '',
                        researchActivities TEXT NOT NULL DEFAULT ''
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_assessments_curriculumId ON assessments(curriculumId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_assessments_difficulty ON assessments(difficulty)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS ai_teaching_plans (
                        planId TEXT NOT NULL PRIMARY KEY,
                        teacherId TEXT NOT NULL,
                        studentLevel TEXT NOT NULL,
                        explanationComplexity TEXT NOT NULL,
                        learningSpeed TEXT NOT NULL,
                        exampleStrategy TEXT NOT NULL,
                        activityStrategy TEXT NOT NULL,
                        recommendedInterventions TEXT NOT NULL DEFAULT ''
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ai_teaching_plans_teacherId ON ai_teaching_plans(teacherId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ai_teaching_plans_studentLevel ON ai_teaching_plans(studentLevel)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS teacher_reviews (
                        reviewId TEXT NOT NULL PRIMARY KEY,
                        contentId TEXT NOT NULL,
                        teacherId TEXT NOT NULL,
                        status TEXT NOT NULL,
                        comments TEXT NOT NULL,
                        reviewedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_teacher_reviews_contentId ON teacher_reviews(contentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_teacher_reviews_teacherId ON teacher_reviews(teacherId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_teacher_reviews_status ON teacher_reviews(status)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS lesson_analytics (
                        analyticsId TEXT NOT NULL PRIMARY KEY,
                        lessonId TEXT NOT NULL,
                        classId TEXT NOT NULL,
                        completionRate INTEGER NOT NULL,
                        engagementScore INTEGER NOT NULL,
                        averageAssessmentScore INTEGER NOT NULL,
                        difficultySignal TEXT NOT NULL,
                        improvementNotes TEXT NOT NULL DEFAULT '',
                        generatedAt INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_lesson_analytics_lessonId ON lesson_analytics(lessonId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_lesson_analytics_classId ON lesson_analytics(classId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_lesson_analytics_generatedAt ON lesson_analytics(generatedAt)")
            }
        }
    }
}
