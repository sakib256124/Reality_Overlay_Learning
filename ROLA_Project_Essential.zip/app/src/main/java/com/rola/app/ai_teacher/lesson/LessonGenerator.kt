package com.rola.app.ai_teacher.lesson

import com.rola.app.domain.model.ARLearningActivity
import com.rola.app.domain.model.GeneratedLesson
import com.rola.app.domain.model.SkillLevel
import com.rola.app.domain.model.TeachingActivityType
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LessonGenerator @Inject constructor() {
    fun generateLesson(
        topic: String,
        objective: String,
        level: SkillLevel,
        relatedConcepts: List<String>,
    ): GeneratedLesson = GeneratedLesson(
        lessonId = "lesson-${UUID.randomUUID()}",
        title = topic,
        objectives = listOf(
            "Define $topic.",
            "Connect $topic to a real-world object.",
            objective,
        ).distinct(),
        explanation = explanationFor(topic, level),
        examples = examplesFor(topic, relatedConcepts),
        experiments = listOf(
            "Observe $topic in a classroom-safe object.",
            "Compare what changes when one variable is adjusted.",
        ),
        arActivities = arActivities(topic, relatedConcepts),
        practiceQuestions = listOf(
            "What is $topic?",
            "Which evidence helps explain $topic?",
            "How does $topic connect to ${relatedConcepts.firstOrNull() ?: "another concept"}?",
        ),
        difficulty = level,
    )

    private fun explanationFor(topic: String, level: SkillLevel): String = when (level) {
        SkillLevel.Beginner -> "$topic is introduced through simple observations, familiar examples, and one key idea at a time."
        SkillLevel.Intermediate -> "$topic is explained by connecting vocabulary, cause-and-effect reasoning, and real-world applications."
        SkillLevel.Advanced -> "$topic is explored through mechanisms, evidence, exceptions, and links to adjacent scientific concepts."
    }

    private fun examplesFor(topic: String, relatedConcepts: List<String>): List<String> =
        (listOf("A real object that demonstrates $topic") + relatedConcepts.map { "$topic connected to $it" })
            .distinct()
            .take(4)

    private fun arActivities(topic: String, relatedConcepts: List<String>): List<ARLearningActivity> = listOf(
        ARLearningActivity(
            activityId = "activity-${UUID.randomUUID()}",
            title = "AR observation: $topic",
            description = "Scan or inspect a relevant object and identify visible evidence of $topic.",
            suggestedObjectIds = relatedConcepts.map { it.lowercase().replace(Regex("[^a-z0-9]+"), "-") }.take(5),
            activityType = TeachingActivityType.ArObservation,
            estimatedMinutes = 8,
        ),
        ARLearningActivity(
            activityId = "activity-${UUID.randomUUID()}",
            title = "3D exploration",
            description = "Use a model or diagram to inspect parts, structure, or process flow.",
            suggestedObjectIds = relatedConcepts.map { it.lowercase().replace(Regex("[^a-z0-9]+"), "-") }.take(5),
            activityType = TeachingActivityType.ThreeDExploration,
            estimatedMinutes = 10,
        ),
    )
}
