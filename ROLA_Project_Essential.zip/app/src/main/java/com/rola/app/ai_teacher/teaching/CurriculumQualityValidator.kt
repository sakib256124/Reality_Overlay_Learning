package com.rola.app.ai_teacher.teaching

import com.rola.app.domain.model.CurriculumQualityReport
import com.rola.app.domain.model.GeneratedCurriculum
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CurriculumQualityValidator @Inject constructor() {
    fun validate(
        curriculum: GeneratedCurriculum,
        knowledgeGraphEvidence: String,
    ): CurriculumQualityReport {
        val hasObjectives = curriculum.modules.all { it.objective.isNotBlank() && it.lessons.all { lesson -> lesson.objectives.isNotEmpty() } }
        val hasAssessments = curriculum.assessments.isNotEmpty() && curriculum.assessments.all { it.mcqQuestions.isNotEmpty() }
        val hasAr = curriculum.modules.flatMap { it.lessons }.all { lesson -> lesson.arActivities.isNotEmpty() }
        val evidenceScore = if (knowledgeGraphEvidence.isNotBlank()) 0.9f else 0.72f
        return CurriculumQualityReport(
            reportId = "quality-${UUID.randomUUID()}",
            scientificAccuracy = evidenceScore,
            levelAlignment = if (curriculum.modules.all { module -> module.lessons.all { it.difficulty == curriculum.request.studentLevel } }) 0.9f else 0.65f,
            objectiveCoverage = if (hasObjectives && hasAssessments) 0.92f else 0.6f,
            contentConsistency = if (hasAr) 0.86f else 0.68f,
            notes = listOf(
                "Knowledge graph evidence: ${if (knowledgeGraphEvidence.isBlank()) "limited" else "available"}",
                "Objectives aligned: $hasObjectives",
                "Assessments included: $hasAssessments",
                "AR activities included: $hasAr",
            ),
        )
    }

    fun placeholderReport(): CurriculumQualityReport = CurriculumQualityReport(
        reportId = "quality-draft",
        scientificAccuracy = 0f,
        levelAlignment = 0f,
        objectiveCoverage = 0f,
        contentConsistency = 0f,
        notes = listOf("Pending validation."),
    )
}
