package com.rola.app.ai_teacher.curriculum

import com.rola.app.ai_teacher.assessment.AssessmentGenerator
import com.rola.app.ai_teacher.lesson.LessonGenerator
import com.rola.app.ai_teacher.teaching.CurriculumQualityValidator
import com.rola.app.data.knowledgegraph.KnowledgeGraphRepository
import com.rola.app.domain.model.CurriculumModule
import com.rola.app.domain.model.CurriculumRequest
import com.rola.app.domain.model.GeneratedCurriculum
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CurriculumGenerator @Inject constructor(
    private val knowledgeGraphRepository: KnowledgeGraphRepository,
    private val lessonGenerator: LessonGenerator,
    private val assessmentGenerator: AssessmentGenerator,
    private val qualityValidator: CurriculumQualityValidator,
) {
    suspend fun generateCurriculum(
        teacherId: String,
        institutionId: String,
        request: CurriculumRequest,
    ): GeneratedCurriculum {
        val search = knowledgeGraphRepository.semanticSearch("${request.subject} ${request.topic}")
        val conceptNames = search.graph.nodes.map { it.name }.distinct().take(6).ifEmpty {
            listOf(request.topic, request.learningObjective)
        }
        val moduleCount = request.durationWeeks.coerceIn(1, 8)
        val modules = (1..moduleCount).map { index ->
            val concept = conceptNames.getOrElse(index - 1) { "${request.topic} application $index" }
            val lessons = listOf(
                lessonGenerator.generateLesson(
                    topic = concept,
                    objective = request.learningObjective,
                    level = request.studentLevel,
                    relatedConcepts = conceptNames,
                ),
            )
            CurriculumModule(
                moduleId = "module-${UUID.randomUUID()}",
                title = "Module $index: $concept",
                objective = if (index == 1) request.learningObjective else "Connect $concept to ${request.topic}.",
                lessons = lessons,
                estimatedHours = 2,
            )
        }
        val assessments = modules.map { module ->
            assessmentGenerator.generateAssessment(
                topic = module.title.substringAfter(": ").ifBlank { request.topic },
                level = request.studentLevel,
            )
        }
        val draft = GeneratedCurriculum(
            curriculumId = "curriculum-${UUID.randomUUID()}",
            teacherId = teacherId,
            institutionId = institutionId,
            request = request,
            title = "${request.gradeLevel} ${request.subject}: ${request.topic}",
            overview = "A ${request.durationWeeks}-week AR-supported curriculum for ${request.learningObjective}.",
            modules = modules,
            assessments = assessments,
            quality = qualityValidator.placeholderReport(),
        )
        return draft.copy(quality = qualityValidator.validate(draft, search.explanation))
    }
}
