package com.rola.app.presentation.ai_teacher

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.School
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AITeacherDashboardScreen(
    onBack: () -> Unit,
    viewModel: AITeacherDashboardViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    val dashboard = uiState.dashboard

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "AI Teacher") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(
                    onClick = {},
                    leadingIcon = { Icon(Icons.Rounded.School, contentDescription = null) },
                    label = { Text(text = "Plans ${dashboard?.curriculumPlans?.size ?: 0}") },
                )
                AssistChip(
                    onClick = {},
                    leadingIcon = { Icon(Icons.Rounded.Psychology, contentDescription = null) },
                    label = { Text(text = "Lessons ${dashboard?.generatedLessons?.size ?: 0}") },
                )
                AssistChip(
                    onClick = {},
                    leadingIcon = { Icon(Icons.Rounded.CheckCircle, contentDescription = null) },
                    label = { Text(text = "Approvals ${dashboard?.pendingApprovals?.size ?: 0}") },
                )
                AssistChip(
                    onClick = {},
                    leadingIcon = { Icon(Icons.Rounded.Quiz, contentDescription = null) },
                    label = { Text(text = "Signals ${dashboard?.lessonAnalytics?.size ?: 0}") },
                )
            }

            AITeacherCard(
                title = "AI Generated Lessons",
                body = dashboard?.generatedLessons
                    ?.joinToString("\n") { "${it.title} - ${it.difficulty.name}" }
                    .orEmpty()
                    .ifBlank { "Generated lessons will appear after a teacher creates a curriculum plan." },
            )
            AITeacherCard(
                title = "Curriculum Plans",
                body = dashboard?.curriculumPlans
                    ?.joinToString("\n") { "${it.title} - ${it.approvalStatus.name}" }
                    .orEmpty()
                    .ifBlank { "Draft, review, approved, and distributed plans appear here." },
            )
            AITeacherCard(
                title = "Student Insights",
                body = dashboard?.studentInsights
                    ?.joinToString("\n")
                    .orEmpty()
                    .ifBlank { "Adaptive insights appear after class activity and assessment data are available." },
            )
            AITeacherCard(
                title = "Suggested Improvements",
                body = dashboard?.suggestedImprovements
                    ?.joinToString("\n")
                    .orEmpty()
                    .ifBlank { "Lesson effectiveness suggestions appear after analytics are collected." },
            )
        }
    }
}

@Composable
private fun AITeacherCard(
    title: String,
    body: String,
) {
    Card(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.small) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(text = body, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
