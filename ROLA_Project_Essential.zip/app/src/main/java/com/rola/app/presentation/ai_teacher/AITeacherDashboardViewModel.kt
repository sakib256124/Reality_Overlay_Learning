package com.rola.app.presentation.ai_teacher

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rola.app.ai_teacher.teaching.AITeacherRepository
import com.rola.app.domain.model.AITeacherDashboard
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class AITeacherDashboardViewModel @Inject constructor(
    aiTeacherRepository: AITeacherRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    private val teacherId: String = savedStateHandle["teacherId"] ?: "local-teacher"
    private val classId: String = savedStateHandle["classId"] ?: "local-class"

    val uiState = aiTeacherRepository.observeDashboard(teacherId, classId)
        .map { AITeacherDashboardUiState(dashboard = it) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = AITeacherDashboardUiState(),
        )
}

data class AITeacherDashboardUiState(
    val dashboard: AITeacherDashboard? = null,
)
