package com.rola.app.data.database.converters

import androidx.room.TypeConverter
import com.rola.app.domain.model.ChatRole
import com.rola.app.domain.model.KnowledgeNodeType
import com.rola.app.domain.model.KnowledgeRelationType
import com.rola.app.domain.model.LearningStatus
import com.rola.app.domain.model.QuizDifficulty
import com.rola.app.domain.model.SkillLevel

class QuizConverters {
    @TypeConverter
    fun fromDifficulty(value: QuizDifficulty): String = value.name

    @TypeConverter
    fun toDifficulty(value: String): QuizDifficulty =
        runCatching { QuizDifficulty.valueOf(value) }.getOrDefault(QuizDifficulty.Easy)

    @TypeConverter
    fun fromLearningStatus(value: LearningStatus): String = value.name

    @TypeConverter
    fun toLearningStatus(value: String): LearningStatus =
        runCatching { LearningStatus.valueOf(value) }.getOrDefault(LearningStatus.Scanned)

    @TypeConverter
    fun fromChatRole(value: ChatRole): String = value.name

    @TypeConverter
    fun toChatRole(value: String): ChatRole =
        runCatching { ChatRole.valueOf(value) }.getOrDefault(ChatRole.Assistant)

    @TypeConverter
    fun fromSkillLevel(value: SkillLevel): String = value.name

    @TypeConverter
    fun toSkillLevel(value: String): SkillLevel =
        runCatching { SkillLevel.valueOf(value) }.getOrDefault(SkillLevel.Beginner)

    @TypeConverter
    fun fromKnowledgeNodeType(value: KnowledgeNodeType): String = value.name

    @TypeConverter
    fun toKnowledgeNodeType(value: String): KnowledgeNodeType =
        runCatching { KnowledgeNodeType.valueOf(value) }.getOrDefault(KnowledgeNodeType.Object)

    @TypeConverter
    fun fromKnowledgeRelationType(value: KnowledgeRelationType): String = value.name

    @TypeConverter
    fun toKnowledgeRelationType(value: String): KnowledgeRelationType =
        runCatching { KnowledgeRelationType.valueOf(value) }.getOrDefault(KnowledgeRelationType.RelatedTo)
}
