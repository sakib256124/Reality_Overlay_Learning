package com.rola.app.ai_teacher.personalization

import com.rola.app.domain.model.AdaptiveTeachingPlan
import com.rola.app.domain.model.LearningProfile
import com.rola.app.domain.model.LearningSpeed
import com.rola.app.domain.model.SkillLevel
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AdaptiveTeachingEngine @Inject constructor() {
    fun adapt(
        teacherId: String,
        profile: LearningProfile?,
    ): AdaptiveTeachingPlan {
        val level = profile?.learningLevel ?: SkillLevel.Beginner
        val speed = profile?.learningSpeed ?: LearningSpeed.Balanced
        return AdaptiveTeachingPlan(
            planId = "adaptive-teaching-${UUID.randomUUID()}",
            teacherId = teacherId,
            studentLevel = level,
            explanationComplexity = when (level) {
                SkillLevel.Beginner -> "simple language, concrete examples, short steps"
                SkillLevel.Intermediate -> "balanced vocabulary, causal reasoning, guided comparison"
                SkillLevel.Advanced -> "scientific vocabulary, mechanisms, exceptions, evidence"
            },
            learningSpeed = speed,
            exampleStrategy = if (profile?.favoriteCategories?.isNotEmpty() == true) {
                "Use examples from ${profile.favoriteCategories.take(3).joinToString()}."
            } else {
                "Start with familiar classroom and home objects."
            },
            activityStrategy = when (speed) {
                LearningSpeed.SlowAndSteady -> "Use short AR activities with reflection pauses."
                LearningSpeed.Balanced -> "Alternate AR exploration, explanation, and quick checks."
                LearningSpeed.Fast -> "Use challenge-based activities and advanced extensions."
            },
            recommendedInterventions = profile?.weakAreas?.map { "Review $it with a visual example." }.orEmpty()
                .ifEmpty { listOf("Run a short diagnostic quiz before the next module.") },
        )
    }
}
